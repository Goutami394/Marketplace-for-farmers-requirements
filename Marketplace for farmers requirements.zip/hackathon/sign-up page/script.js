// Store user data in localStorage (for demo purposes)
const users = JSON.parse(localStorage.getItem('users')) || {};
const resetRequests = JSON.parse(localStorage.getItem('resetRequests')) || {};

document.addEventListener("DOMContentLoaded", function() {
    // Duration of the splash screen in milliseconds
    const splashDuration = 30; 

    // Function to hide the splash screen and show the main content
    function hideSplashScreen() {
        const splashScreen = document.getElementById('splash-screen');
        const mainContent = document.getElementById('main-content');

        splashScreen.style.opacity = 0;

        setTimeout(() => {
            splashScreen.style.display = 'none';
            mainContent.style.display = 'block';
            // Optionally, redirect to the main page
            window.location.href = 'index.html';
        }, 1000); // Match this to the CSS transition duration
    }

    // Set a timeout to hide the splash screen after the specified duration
    setTimeout(hideSplashScreen, splashDuration);
});

// Show Sign-Up Form
function showSignUp() {
    document.getElementById('form-container').innerHTML = `
        <h2>Sign Up</h2>
        <form id="signUpForm">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>
            
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>
            
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
            
            <div class="checkbox-container">
                <input type="checkbox" id="showPasswordSignup">
                <label for="showPasswordSignup">Show my password</label>
            </div>
            
            <div class="checkbox-container">
                <input type="checkbox" id="terms" name="terms" required>
                <label for="terms">I agree to the terms and conditions</label>
            </div>
            
            <button type="submit">Sign Up</button>
        </form>
        <div id="message"></div>
        <a href="index.html">Back to Main Page</a>
    `;
    
    document.getElementById('showPasswordSignup').addEventListener('change', function() {
        const passwordField = document.getElementById('password');
        passwordField.type = this.checked ? 'text' : 'password';
    });

    document.getElementById('signUpForm').addEventListener('submit', function(event) {
        event.preventDefault();
        
        const username = document.getElementById('username').value;
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        const terms = document.getElementById('terms').checked;
        
        if (!terms) {
            document.getElementById('message').textContent = 'Please agree to the terms and conditions.';
            return;
        }
        
        // Check if email already exists
        const emailExists = Object.values(users).some(user => user.email === email);
        
        if (emailExists) {
            document.getElementById('message').textContent = 'An account with this email already exists.';
            return;
        }
        
        // Save user to localStorage
        users[username] = { email, password, profile: {} };
        localStorage.setItem('users', JSON.stringify(users));
        
        // Redirect to profile setup page
        window.location.href = 'profileSetup.html';
    });
}

// Show Sign-In Form
function showSignIn() {
    document.getElementById('form-container').innerHTML = `
        <h2>Sign In</h2>
        <form id="signInForm">
            <label for="signin-username">Username:</label>
            <input type="text" id="signin-username" name="username" required>
            
            <label for="signin-password">Password:</label>
            <input type="password" id="signin-password" name="password" required>
            
            <div class="checkbox-container">
                <input type="checkbox" id="showPasswordSignIn">
                <label for="showPasswordSignIn">Show my password</label>
            </div>
            
            <button type="submit">Sign In</button>
        </form>
        <div id="signin-message"></div>
        <a href="passwordReset.html">Forgot your password?</a>
        <a href="index.html">Back to Main Page</a>
    `;
    
    document.getElementById('showPasswordSignIn').addEventListener('change', function() {
        const passwordField = document.getElementById('signin-password');
        passwordField.type = this.checked ? 'text' : 'password';
    });

    document.getElementById('signInForm').addEventListener('submit', function(event) {
        event.preventDefault();
        
        const username = document.getElementById('signin-username').value;
        const password = document.getElementById('signin-password').value;
        
        if (users[username] && users[username].password === password) {
            // Redirect to profile setup page if profile is not set
            if (Object.keys(users[username].profile).length === 0) {
                window.location.href = 'profileSetup.html';
            } else {
                // Redirect to sign-in confirmation page
                window.location.href = 'signInConfirmation.html';
            }
        } else {
            document.getElementById('signin-message').textContent = 'Incorrect username or password.';
        }
    });
}

// Show Profile Setup Form
function showProfileSetup() {
    document.getElementById('form-container').innerHTML = `
        <h2>Setup Your Profile</h2>
        <form id="profileSetupForm">
            <label for="fullName">Full Name:</label>
            <input type="text" id="fullName" name="fullName" required>
            
            <label for="bio">Bio:</label>
            <textarea id="bio" name="bio"></textarea>
            
            <label for="profilePicture">Profile Picture</label>
            <input type="text" id="profilePicture" name="profilePicture">
            
            <button type="submit">Save Profile</button>
        </form>
        <div id="profile-message"></div>
    `;
    
    document.getElementById('profileSetupForm').addEventListener('submit', function(event) {
        event.preventDefault();
        
        const username = prompt('Please enter your username:'); // Prompt user to enter username
        if (!username || !users[username]) {
            document.getElementById('profile-message').textContent = 'User not found.';
            return;
        }
        
        const fullName = document.getElementById('fullName').value;
        const bio = document.getElementById('bio').value;
        const profilePicture = document.getElementById('profilePicture').value;
        
        // Update user profile
        users[username].profile = { fullName, bio, profilePicture };
        localStorage.setItem('users', JSON.stringify(users));
        
        document.getElementById('profile-message').textContent = 'Profile updated successfully!';
        
        // Optionally, redirect to a profile page or dashboard
        window.location.href = 'profilePage.html'; // Replace with your profile page URL
    });
}

// Show Sign-In Confirmation
function showSignInConfirmation() {
    document.getElementById('form-container').innerHTML = `
        <h2>Sign In Confirmation</h2>
        <p>Welcome back! Your sign-in was successful.</p>
        <a href="profilePage.html">Go to your profile</a>
        <a href="index.html">Back to Main Page</a>
    `;
}

// Show Password Reset Request Form
function showPasswordReset() {
    document.getElementById('form-container').innerHTML = `
        <h2>Password Reset</h2>
        <form id="resetRequestForm">
            <label for="reset-email">Enter your email:</label>
            <input type="email" id="reset-email" name="email" required>
            
            <button type="submit">Send Reset Email</button>
        </form>
        <div id="reset-message"></div>
        <a href="index.html">Back to Main Page</a>
    `;
    
    document.getElementById('resetRequestForm').addEventListener('submit', function(event) {
        event.preventDefault();
        
        const email = document.getElementById('reset-email').value;
        
        // Simulate sending a password reset email
        const user = Object.values(users).find(user => user.email === email);
        
        if (user) {
            const resetToken = Math.random().toString(36).substring(2); // Generate a random token
            resetRequests[resetToken] = { email };
            localStorage.setItem('resetRequests', JSON.stringify(resetRequests));
            
            document.getElementById('reset-message').textContent = 'A password reset link has been sent to your email address.';
        } else {
            document.getElementById('reset-message').textContent = 'Email not found.';
        }
    });
}

// Show Password Reset Form
function showPasswordResetForm(token) {
    document.getElementById('form-container').innerHTML = `
        <h2>Reset Your Password</h2>
        <form id="resetPasswordForm">
            <input type="hidden" id="reset-token" value="${token}">
            
            <label for="new-password">New Password:</label>
            <input type="password" id="new-password" name="password" required>
            
            <div class="checkbox-container">
                <input type="checkbox" id="showPasswordReset">
                <label for="showPasswordReset">Show my password</label>
            </div>
            
            <button type="submit">Reset Password</button>
        </form>
        <div id="reset-password-message"></div>
    `;
    
    document.getElementById('showPasswordReset').addEventListener('change', function() {
        const passwordField = document.getElementById('new-password');
        passwordField.type = this.checked ? 'text' : 'password';
    });

    document.getElementById('resetPasswordForm').addEventListener('submit', function(event) {
        event.preventDefault();
        
        const token = document.getElementById('reset-token').value;
        const newPassword = document.getElementById('new-password').value;
        
        const request = resetRequests[token];
        
        if (request) {
            const user = Object.keys(users).find(username => users[username].email === request.email);
            
            if (user) {
                users[user].password = newPassword;
                localStorage.setItem('users', JSON.stringify(users));
                localStorage.removeItem('resetRequests');
                
                document.getElementById('reset-password-message').textContent = 'Your password has been reset successfully!';
                // Optionally, redirect to sign-in page
                window.location.href = 'index.html'; // Replace with your sign-in page URL
            } else {
                document.getElementById('reset-password-message').textContent = 'Invalid token.';
            }
        } else {
            document.getElementById('reset-password-message').textContent = 'Invalid or expired token.';
        }
    });
}

// Determine which function to call based on the page URL or routing logic
(function() {
    const path = window.location.pathname;
    if (path.includes('signUp.html')) {
        showSignUp();
    } else if (path.includes('signIn.html')) {
        showSignIn();
    } else if (path.includes('profileSetup.html')) {
        showProfileSetup();
    } else if (path.includes('signInConfirmation.html')) {
        showSignInConfirmation();
    } else if (path.includes('passwordReset.html')) {
        showPasswordReset();
    } else if (path.includes('resetPassword.html')) {
        const urlParams = new URLSearchParams(window.location.search);
        const token = urlParams.get('token');
        if (token) {
            showPasswordResetForm(token);
        }
    }
})();
