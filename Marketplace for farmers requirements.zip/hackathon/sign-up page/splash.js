document.addEventListener("DOMContentLoaded", function() {
    // Duration the splash screen will be visible (in milliseconds)
    const splashDuration = 3000;

    // Reference to the splash screen and main content
    const splashScreen = document.getElementById('splash-screen');
    const mainContent = document.getElementById('main-content');

    // Function to hide the splash screen and show the main content
    function showMainContent() {
        splashScreen.style.display = 'none';
        mainContent.style.display = 'block';
    }

    // Set a timeout to hide the splash screen after the specified duration
    setTimeout(showMainContent, splashDuration);
});
