use app;
CREATE TABLE signup_farmers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    phone VARCHAR(20),
    location VARCHAR(255) NOT NULL,
    password VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE signup_buyers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    phone VARCHAR(20) NOT NULL,
    interests VARCHAR(255),
    location VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
ALTER TABLE signup_farmers ADD COLUMN farmsize VARCHAR(255);
ALTER TABLE signup_farmers MODIFY farmsize VARCHAR(255) DEFAULT 'unknown';
use app;
ALTER TABLE signup_farmers
DROP COLUMN farmsize;
SELECT * FROM signup_farmers;
ALTER TABLE signup_farmers
DROP COLUMN farm_size;
use app;
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    name VARCHAR(255) NOT NULL,
    phone VARCHAR(20)UNIQUE NOT NULL,
    user_type ENUM('farmer', 'buyer') NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
use app;
drop table test_users;
UPDATE users
SET name = ?, phone = ?, location = ?, bio = ?
WHERE email = ?;
use app;
drop table stakeholders;
ALTER TABLE Users ADD COLUMN user_type ENUM('farmer', 'buyer') NOT NULL;
DESCRIBE Users;
ALTER TABLE Users MODIFY user_type VARCHAR(20);
use app;
drop table profile;
ALTER TABLE Users DROP COLUMN password;
ALTER TABLE Users DROP COLUMN bankaccount;
use app;
UPDATE users
SET name = ?, phone = ?, location = ?, bio = ?
WHERE email = ?;
UPDATE users
SET name = 'Bharathi Joshi', bio = 'HI', phone = '9182195839'
WHERE email = 'bharathijoshi75@gmail.com';
drop table users;
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) UNIQUE,
    name VARCHAR(255),
    bio TEXT,
    phone VARCHAR(20),
    user_type ENUM('farmer', 'buyer')
);
ALTER TABLE signup_farmers
DROP PRIMARY KEY,
ADD PRIMARY KEY (email);
drop table users;
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    name VARCHAR(255),
    bio TEXT,
    phone VARCHAR(20),
    user_type ENUM('farmer', 'buyer'),
    FOREIGN KEY (email) REFERENCES signup_farmers(email),
    FOREIGN KEY (email) REFERENCES signup_buyers(email)
);
drop table users;
CREATE TABLE users (
    email VARCHAR(255) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    bio TEXT,
    phone VARCHAR(20),
    user_type ENUM('buyer', 'farmer') NOT NULL
);

use app;
ALTER TABLE users ADD COLUMN bank_account VARCHAR(255);
ALTER TABLE users ADD COLUMN address VARCHAR(255);
ALTER TABLE users ADD COLUMN business_information TEXT;
ALTER TABLE users DROP COLUMN bio;
use app;
ALTER TABLE users DROP COLUMN bank_account;
use app;
CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_name VARCHAR(255) NOT NULL,
    description TEXT,
    cost DECIMAL(10, 2) NOT NULL,
    image_url VARCHAR(255)
);
ALTER TABLE users ADD COLUMN id INT AUTO_INCREMENT PRIMARY KEY;
ALTER TABLE users DROP PRIMARY KEY;
ALTER TABLE users DROP INDEX email;
ALTER TABLE users ADD COLUMN id INT AUTO_INCREMENT PRIMARY KEY;