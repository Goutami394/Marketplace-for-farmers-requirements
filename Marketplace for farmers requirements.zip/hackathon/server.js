const express = require('express');
const mysql = require('mysql');
const path = require('path');
const multer = require('multer'); // Add this line
const bodyParser = require('body-parser'); // Middleware for parsing request bodies
const bcrypt = require('bcrypt'); // Ensure bcrypt is required
const nodemailer = require('nodemailer'); // Ensure nodemailer is required at the top of the file


const app = express();
const port = 3000;

// Database connection setup
const db = mysql.createConnection({ host: "localhost", user: "root", password: "W7301@jqir#", database: "app", }); 

db.connect((err) => {
    if (err) throw err;
    console.log('Connected to database.');
});

// Middleware for parsing JSON data
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Serve static files from the 'public' directory
app.use(express.static(path.join(__dirname, 'public')));

// Routes for serving HTML pages
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/chooserole', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'chooseRole.html'));
});

app.get('/signup_confirmation', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'signup_confirmation.html'))
});

app.get('/signin', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'signin.html'));
})

app.get('/setup_profile', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'setup_profile.html'));
});

app.get('/profile_saved', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'profile_saved.html'));
});

app.get('/index1', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index1.html'));
});


// Route for handling form submission
app.post('/submit_farmer', (req, res) => {
    const { name, phone, email, location, password } = req.body;
    
    if (!validateEmail(email) || !validatePassword(password)) {
        return res.status(400).send('Invalid email or password.');
    }

    // Check if the email already exists
    const checkEmailQuery = 'SELECT email FROM signup_farmers WHERE email = ?';
    db.query(checkEmailQuery, [email], (err, results) => {
        if (err) {
            console.error('Error checking email:', err);
            return res.status(500).send('Internal Server Error');
        }

        if (results.length > 0) {
            return res.sendStatus(400).send('Email already exists.Enter another email.');
        }

        // If email does not exist, proceed with the signup
        bcrypt.hash(password, 10, (err, hashedPassword) => {
            if (err) {
                console.error('Error hashing password:', err);
                return res.json({ success: false, message: 'An error occurred.' });
            }

            const insertQuery = 'INSERT INTO signup_farmers (name, phone, email, location, password) VALUES (?, ?, ?, ?, ?)';
            db.query(insertQuery, [name, phone, email, location, hashedPassword], (err, result) => {
                if (err) {
                    console.error('Error inserting data:', err);
                    return res.status(500).send('Internal Server Error');
                } 
                res.redirect('/signup_confirmation.html') // Redirect on success
            });
        });
    });
});

function validateEmail(email) {
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailPattern.test(email);
}

function validatePassword(password) {
    const minLength = 8;
    const uppercasePattern = /[A-Z]/;
    const lowercasePattern = /[a-z]/;
    const digitPattern = /\d/;
    const specialCharPattern = /[!@#$%^&*]/;

    return (
        password.length >= minLength &&
        uppercasePattern.test(password) &&
        lowercasePattern.test(password) &&
        digitPattern.test(password) &&
        specialCharPattern.test(password)
    );
}

function sendConfirmationEmail(email) {
    const transporter = nodemailer.createTransport({
        service: 'smtp.gmail.com',
        auth: {
            user: 'joshibhavana938@gmail.com',
            pass: 'giwijuemiaarxwyy.' // Ensure you replace this with your actual password
        }
    });

    const mailOptions = {
        from: 'joshibhavana938@gmail.com',
        to: email,
        subject: 'Signup Confirmation',
        text: 'Thank you for signing up!'
    };

    return transporter.sendMail(mailOptions);
}


app.post('/submit_buyer', (req, res) => {
    const { name, email, phone, location, password } = req.body;

    if (!validateEmail(email) || !validatePassword(password)) {
        return res.status(400).send('Invalid email or password.');
    }

    bcrypt.hash(password, 10, (err, hashedPassword) => {
        if (err) {
            console.error('Error hashing password:', err);
            return res.json({ success: false, message: 'An error occurred.' });
        }
    const query = 'INSERT INTO signup_buyers (name, email, phone, location, password) VALUES (?, ?, ?, ?, ?)';
    db.query(query, [name, email, phone, location, password], (err, result) => {
        if (err) {
            return res.send('<p>Email already exists.Enter another email.</p>' ,redirect('/signup_buyer.html'));
        }
        res.redirect('/signup_confirmation.html'); // Redirect on success
    });
    });
});
function validateEmail(email) {
const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
return emailPattern.test(email);
}

function validatePassword(password) {
const minLength = 8;
const uppercasePattern = /[A-Z]/;
const lowercasePattern = /[a-z]/;
const digitPattern = /\d/;
const specialCharPattern = /[!@#$%^&*]/;

return (
    password.length >= minLength &&
    uppercasePattern.test(password) &&
    lowercasePattern.test(password) &&
    digitPattern.test(password) &&
    specialCharPattern.test(password)
);
}

function sendConfirmationEmail(email) {
const transporter = nodemailer.createTransport({
    service: 'smtp.gmail.com',
    auth: {
        user: 'joshibhavana938@gmail.com',
        pass: 'giwijuemiaarxwyy'
    }
});


const mailOptions = {
    from: 'joshibhavana938@gmail.com',
    to: email,
    subject: 'Signup Confirmation',
    text: 'Thank you for signing up!'
};

return transporter.sendMail(mailOptions);
}

// Endpoint for signing in
app.post('/signin', async (req, res) => {
    const { email, password } = req.body;

    const checkEmailQuery = 'SELECT email, password FROM signup_farmers WHERE email = ?';
    db.query(checkEmailQuery, [email], async (err, results) => {
        if (err) {
            console.error('Error checking email:', err);
            return res.status(500).send('Internal Server Error');
        }

        if (results.length > 0) {
            const foundUser = results[0];
            console.log('Stored hashed password:', foundUser.password);

            try {
                // Compare the provided password with the hashed password from the database
                const match = await bcrypt.compare(password, foundUser.password);
                console.log('Password comparison result:', match);

                if (match) {
                    return res.json({ success: true });
                } else {
                    return res.json({ success: false, message: 'Incorrect password.' });
                }
            } catch (compareErr) {
                console.error('Error comparing passwords:', compareErr);
                return res.json({ success: false, message: 'An error occurred during password comparison.' });
            }
        } else {
            return res.json({ success: false, message: 'Email not found.' });
        }
    });
});

// Route to setup profile
app.post('/setup_profile',(req, res) => {
    const { name, business_information, email, phone, address, user_type } = req.body;

    const sql = 'INSERT INTO users (name, business_information, email, phone, address, user_type) VALUES (?, ?, ?, ?, ?, ?)';
    const values = [name, business_information, email, phone, address, user_type];

    // Check if the email already exists
    const checkEmailSql = 'SELECT * FROM users WHERE email = ?';
    db.query(checkEmailSql, [email], (err, results) => {
        if (err) {
            console.error('Error checking email:', err);
            res.status(500).send('Error setting up profile');
            return;
        }

        if (results.length > 0) {
            // Email already exists
            res.status(400).send('Email already exists');
            return;
        }
// Redirect based on user_type
if (user_type.toLowerCase() === 'farmer') {
    res.redirect('/farmers-market.html');
} else if (user_type.toLowerCase() === 'buyer') {
    res.redirect('/index1.html');
} else {
    res.status(400).send('Invalid user type');
}
    });
});

// Place an order
app.post('/place-order', (req, res) => {
    const { product_id, quantity } = req.body;

    const placeOrderQuery = 'INSERT INTO orders (product_id, quantity) VALUES (?, ?)';
    db.query(placeOrderQuery, [product_id, quantity], (err, result) => {
        if (err) {
            console.error('Error placing order:', err);
            return res.status(500).json({ success: false, message: 'Internal Server Error' });
        }
        res.json({ success: true, message: 'Order placed successfully' });
    });
});

app.get('/search', (req, res) => {
    const { name, category, minPrice, maxPrice } = req.query;

    let query = 'SELECT * FROM products WHERE 1=1';
    const queryParams = [];

    if (name) {
        query += ' AND name LIKE ?';
        queryParams.push(`%${name}%`);
    }

    if (category) {
        query += ' AND category = ?';
        queryParams.push(category);
    }

    if (minPrice) {
        query += ' AND price >= ?';
        queryParams.push(parseFloat(minPrice));
    }

    if (maxPrice) {
        query += ' AND price <= ?';
        queryParams.push(parseFloat(maxPrice));
    }

    db.query(query, queryParams, (err, results) => {
        if (err) {
            console.error('Error searching for products:', err);
            return res.status(500).send('Internal Server Error');
        }

        res.json(results);
    });
});

app.get('/product', (req, res) => {
    const { id } = req.query;
    const query = 'SELECT * FROM products WHERE id = ?';

    db.query(query, [id], (err, results) => {
        if (err) {
            console.error('Error fetching product details:', err);
            return res.status(500).send('Internal Server Error');
        }

        res.json(results[0]);
    });
});

app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});