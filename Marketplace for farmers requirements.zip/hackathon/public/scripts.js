document.addEventListener("DOMContentLoaded", () => {
    // Display the main content after the splash screen
    setTimeout(() => {
        document.getElementById('splash-screen').style.display = 'none';
        document.getElementById('main-content').style.display = 'block';
    }, 5000); // Adjust the time as needed for the splash screen duration

    document.getElementById('get-started-button')?.addEventListener('click', () => {
        window.location.href = 'chooserole.html';
    });

    // Handle signup form submissions
    document.getElementById('signupForm')?.addEventListener('submit', (event) => {
        event.preventDefault();
        submitForm();
    });

    // Handle profile setup form submissions
    document.getElementById('ProfileForm')?.addEventListener('submit', (event) => {
        event.preventDefault();
        submitProfileForm();
    });

    // Handle signin form submissions
    document.getElementById('signinForm')?.addEventListener('submit', (event) => {
    event.preventDefault();
    signin();
});
});



function chooseRole(role) {
    // Redirect to different signup pages based on the role selected
    switch (role) {
        case 'Farmer':
            window.location.href = 'signup_farmer.html';
            break;
        case 'Buyer':
            window.location.href = 'signup_buyer.html';
            break;
        default:
            alert('Unknown role selected');
    }
}


function submitForm() {
    const form = document.getElementById('signupForm');
    const formData = new FormData(form);

    fetch('/register', {
        method: 'POST',
        body: JSON.stringify(Object.fromEntries(formData.entries())),
        headers: {
            'Content-Type': 'application/json'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            window.location.href = 'signup_confirmation.html'; // Redirect on success
        } else {
            alert(data.message || 'Registration failed. Please try again.');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('An error occurred. Please try again later.');
    });
}

document.addEventListener('DOMContentLoaded', () => {
    const signInForm = document.getElementById('signin-form');

    if (signInForm) {
        signInForm.addEventListener('submit', async (event) => {
            event.preventDefault();

            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;

            const response = await fetch('/signin', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ email, password })
            });

            const result = await response.json();

            if (result.success) {
                alert('Sign in successful!');
                // Redirect to appropriate page after successful sign in
                window.location.href = 'index1.html';
            } else {
                alert(`Sign in failed: ${result.message}`);
            }
        });
    }
});

document.addEventListener('DOMContentLoaded', () => {
    const profileForm = document.getElementById('ProfileForm');
    const userId = 1; // Replace with actual user ID from session or auth

    // Fetch and populate profile data
    async function loadProfile() {
        const response = await fetch(`/profile?id=${userId}`);
        const profile = await response.json();

        document.getElementById('name').value = profile.name;
        document.getElementById('businessinformation').value = profile.businessinformation;
        document.getElementById('email').value = profile.email;
        document.getElementById('phone').value = profile.phone;
        document.getElementById('address').value = profile.address;
        document.getElementById('user_type').value = profile.user_type;

        // Optionally display the profile picture
        if (profile.profilePicture) {
            const img = document.createElement('img');
            img.src = `/uploads/${profile.profilePicture}`;
            img.alt = 'Profile Picture';
            document.body.insertBefore(img, profileForm);
        }
    }

    // Initialize profile form with existing data
    loadProfile();

    // Handle profile form submission
    profileForm.addEventListener('submit', (event) => {
        event.preventDefault();
        const formData = new FormData(profileForm);

        // Include user ID in the form data
        formData.append('id', userId);

        fetch('/update_profile', {
            method: 'POST',
            body: formData
        }).then(response => {
            if (response.ok) {
                window.location.href = document.getElementById('user_type').value === 'farmer' ? '/farmers-market.html' : '/buyers-market.html';
            } else {
                alert('Error updating profile.');
            }
        }).catch(error => {
            console.error('Error:', error);
            alert('Error updating profile.');
        });
    });
});

function togglePasswordVisibility() {
    const passwordInput = document.getElementById('password');
    const eyeIcon = document.querySelector('.eye-icon');

    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        eyeIcon.textContent = '🙈'; // Change to a different icon, e.g., closed eye
    } else {
        passwordInput.type = 'password';
        eyeIcon.textContent = '👁'; // Change back to the open eye icon
    }
}

function validateForm() {
    const password = document.getElementById('password').value;
    const email = document.getElementById('email').value;
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!emailPattern.test(email)) {
        alert('Please enter a valid email address.');
        return false;
    }

    if (!validatePassword(password)) {
        alert('Password must be at least 8 characters long and include at least one uppercase letter, one lowercase letter, one digit, and one special character.');
        return false;
    }

    // If the form is valid, you can submit it or make an AJAX call here
    return true;
}

function validatePassword(password) {
    const minLength = 8;
    const uppercasePattern = /[A-Z]/;
    const lowercasePattern = /[a-z]/;
    const digitPattern = /\d/;
    const specialCharPattern = /[!@#$%^&*]/;

    if (
        password.length >= minLength &&
        uppercasePattern.test(password) &&
        lowercasePattern.test(password) &&
        digitPattern.test(password) &&
        specialCharPattern.test(password)
    ) {
        return true;
    }
    return false;
}

function sendConfirmationEmail(email) {
    const transporter = nodemailer.createTransport({
        service: 'smtp.gmail.com',
        auth: {
            user: 'joshibhavana938@gmail.com',
            pass: 'giwijuemiaarxwyy'
        }
    });

    const mailOptions = {
        from: 'joshibhavana938@gmail.com',
        to: email,
        subject: 'Signup Confirmation',
        html: `
            <h1>Thank you for signing up!</h1>
            <p>You have successfuly signed up.</p>

        `
    };

    return transporter.sendMail(mailOptions);
}


function navigateToFarmersMarket() {
    window.location.href = 'farmers-market.html';
}

document.addEventListener('DOMContentLoaded', () => {
    // Display selected products and rice types if on the selected-products.html page
    if (window.location.pathname.endsWith('selected-products.html')) {
        displaySelectedProducts();
    }
});

// Fetch and display selected products and rice types
document.addEventListener('DOMContentLoaded', () => {
    fetch('http://localhost:3000/api/selected-products')
        .then(response => response.json())
        .then(data => {
            const selectedProducts = data.selectedProducts;
            const selectedRiceTypes = data.selectedRiceTypes;

            // Apply the selected class to products and rice types
            selectedProducts.forEach(product => {
                const productElement = document.querySelector(`.product[data-name="${product}"]`);
                if (productElement) {
                    productElement.classList.add('selected');
                }
            });

            selectedRiceTypes.forEach(riceType => {
                const riceTypeElement = document.querySelector(`.rice-type[data-name="${riceType}"]`);
                if (riceTypeElement) {
                    riceTypeElement.classList.add('selected');
                }
            });

            // Display selected products on the selected-products.html page
            if (window.location.pathname.endsWith('selected-products.html')) {
                displaySelectedProducts();
            }
        });
});

document.addEventListener("DOMContentLoaded", () => {
    // Get all forms for adding to cart and buying now
    const addToCartForms = document.querySelectorAll('.add-to-cart-form');
    const buyNowForms = document.querySelectorAll('.buy-now-form');

    // Function to handle adding items to cart
    function handleAddToCart(event) {
        event.preventDefault(); // Prevent form submission

        const form = event.target;
        const quantityInput = form.querySelector('input[name="quantity"]');
        const quantity = parseInt(quantityInput.value, 10);

        // Example of sending data to the server
        fetch('/add_to_cart', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                productId: form.dataset.productId, // You may need to set this in your HTML
                quantity: quantity
            })
        })
        .then(response => response.json())
        .then(result => {
            if (result.success) {
                alert('Item added to cart!');
            } else {
                alert('Failed to add item to cart.');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred. Please try again later.');
        });
    }

    // Function to handle buying now
    function handleBuyNow(event) {
        event.preventDefault(); // Prevent form submission

        const form = event.target;

        // Example of sending data to the server
        fetch('/buy_now', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                productId: form.dataset.productId // You may need to set this in your HTML
            })
        })
        .then(response => response.json())
        .then(result => {
            if (result.success) {
                window.location.href = 'checkout.html'; // Redirect to checkout or a success page
            } else {
                alert('Failed to process purchase.');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred. Please try again later.');
        });
    }

    // Add event listeners to add-to-cart forms
    addToCartForms.forEach(form => {
        form.addEventListener('submit', handleAddToCart);
    });

    // Add event listeners to buy-now forms
    buyNowForms.forEach(form => {
        form.addEventListener('submit', handleBuyNow);
    });
});

document.addEventListener('DOMContentLoaded', () => {
    const submittedDetailsContainer = document.getElementById('submitted-details-container');
    const submittedDetails = JSON.parse(localStorage.getItem('submittedDetails')) || [];

    submittedDetails.forEach(detail => {
        const productDiv = document.createElement('div');
        productDiv.classList.add('product-details');

        const nameLabel = document.createElement('label');
        nameLabel.textContent = ProductName; {detail.productName};

        const descriptionLabel = document.createElement('label');
        descriptionLabel.textContent = Description; {detail.description};

        const costLabel = document.createElement('label');
        costLabel.textContent = Cost; {detail.cost} Rupees;

        productDiv.appendChild(nameLabel);
        productDiv.appendChild(descriptionLabel);
        productDiv.appendChild(costLabel);

        // Append image if available
        if (detail.imageFile) {
            const imageLabel = document.createElement('label');
            imageLabel.textContent = 'Product Image:';
            
            const image = document.createElement('img');
            image.src = detail.imageFile;
            image.alt = detail.productName;
            
            productDiv.appendChild(imageLabel);
            productDiv.appendChild(image);
        }

        submittedDetailsContainer.appendChild(productDiv);
    });
})

document.addEventListener('DOMContentLoaded', () => {
    const searchForm = document.getElementById('search-form');
    const searchResults = document.getElementById('search-results');

    if (searchForm) {
        searchForm.addEventListener('submit', async (event) => {
            event.preventDefault();

            const formData = new FormData(searchForm);
            const searchParams = new URLSearchParams();

            for (const [key, value] of formData.entries()) {
                if (value) {
                    searchParams.append(key, value);
                }
            }

            const response = await fetch(`/search?${searchParams.toString()}`);
            const results = await response.json();

            searchResults.innerHTML = '';

            if (results.length > 0) {
                results.forEach(product => {
                    const productElement = document.createElement('div');
                    productElement.classList.add('product');

                    productElement.innerHTML = `
                        <h3><a href="product.html?id=${product.id}">${product.name}</a></h3>
                        <p>Category: ${product.category}</p>
                        <p>Price: $${product.price.toFixed(2)}</p>
                    `;

                    searchResults.appendChild(productElement);
                });
            } else {
                searchResults.innerHTML = '<p>No products match the search criteria.</p>';
            }
        });
    }
});
